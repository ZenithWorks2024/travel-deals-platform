// Update the price section in DealDetail.tsx
// ... (previous imports remain the same)

export default function DealDetail({
  // ... (previous props remain the same)
}) {
  const discount = Math.round(((originalPrice - price) / originalPrice) * 100);
  // Convert INR to USD (approximate rate)
  const usdPrice = Math.round(price / 83);
  const usdOriginalPrice = Math.round(originalPrice / 83);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      {/* ... (previous JSX remains the same until price section) */}
      
      {/* Price Section */}
      <div className="bg-primary-50 rounded-lg p-6">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-sm text-gray-600">Deal Price</p>
            <div className="flex items-center space-x-3">
              <span className="text-3xl font-bold text-primary-600">${usdPrice.toLocaleString()}</span>
              <span className="text-lg text-gray-500 line-through">${usdOriginalPrice.toLocaleString()}</span>
              <span className="bg-primary-600 text-white px-3 py-1 rounded-full text-sm">
                {discount}% OFF
              </span>
            </div>
          </div>
          <a 
            href={backLink}
            target="_blank"
            rel="noopener noreferrer"
            className="bg-primary-600 text-white px-6 py-3 rounded-lg hover:bg-primary-700 flex items-center space-x-2"
          >
            <ExternalLink className="w-4 h-4" />
            <span>Book Now</span>
          </a>
        </div>
      </div>

      {/* ... (rest of the JSX remains the same) */}
    </div>
  );
}