// Major airlines worldwide
export const airlines = [
  'Air Canada',
  'Air France',
  'Air India',
  'American Airlines',
  'British Airways',
  'Cathay Pacific',
  'Delta Air Lines',
  'Emirates',
  'Etihad Airways',
  'Japan Airlines',
  'KLM',
  'Lufthansa',
  'Qatar Airways',
  'Singapore Airlines',
  'Swiss International Air Lines',
  'Turkish Airlines',
  'United Airlines',
  'Virgin Atlantic'
];